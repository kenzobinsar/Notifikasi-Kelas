# Android-Schedule-Alert
Schedule Alert adalah aplikasi Android yang dibangun dengan Java untuk mengirimkan notifikasi harian terkait jadwal kuliah. Aplikasi ini dirancang untuk membantu mahasiswa tetap disiplin dengan jadwal akademiknya melalui pengingat yang tepat waktu di perangkat seluler mereka.

# Tools Used
- Andriod Studio
- Java
